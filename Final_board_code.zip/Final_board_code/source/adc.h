#ifndef __ADC_H__
#define __ADC_H__

void setupADC(void);
int getFirstADCValue(void);
int getSecondADCValue(void);

#endif
