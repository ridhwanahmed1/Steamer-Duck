/*
*  Credit to ECE 3140 / CS 3420 UART0 Example code
*
* 	This UART is configured to print to the virtual serial port that is
* 	created by the USB Debug cable.
*
*/
#include <pin_mux.h>
#include <clock_config.h>
#include <stdio.h>
#include <board.h>
#include <MKL46Z4.h>
#include <fsl_debug_console.h>

#include "adc.h"
#include "utils.h"

const int RED_LED_PIN = 29;
const int SWITCH_1_PIN = 3;
SIM_Type* global_SIM = SIM;
PORT_Type* global_PORTE = PORTE;
GPIO_Type* global_PTE = PTE;
PORT_Type* global_PORTC = PORTC;
GPIO_Type* global_PTC = PTC;


void setupSwitch(void) {
	// setup variables so we can see them in debugger
	// if you get rid of this it seems the compiler just optimizes the variables away
	// this is for educational purposes
	global_SIM = global_SIM;
	global_PORTE = global_PORTE;
	global_PTE = global_PTE;
	global_PORTC = global_PORTC;
	global_PTC = global_PTC;

	// setup switch 1
	SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK; //Enable the clock to port C
	PORTC->PCR[SWITCH_1_PIN] &= ~PORT_PCR_MUX(0b111); // Clear PCR Mux bits for PTC3
	PORTC->PCR[SWITCH_1_PIN] |= PORT_PCR_MUX(0b001); // Set up PTC3 as GPIO
	PTC->PDDR &= ~GPIO_PDDR_PDD(1 << SWITCH_1_PIN); // make it input
	PORTC->PCR[SWITCH_1_PIN] |= PORT_PCR_PE(1); // Turn on the pull enable
	PORTC->PCR[SWITCH_1_PIN] |= PORT_PCR_PS(1); // Enable the pullup resistor
	PORTC->PCR[SWITCH_1_PIN] &= ~PORT_PCR_IRQC(0b1111); // Clear IRQC bits for PTC3
	PORTC->PCR[SWITCH_1_PIN] |= PORT_PCR_IRQC(0b1011); // Set up the IRQC to interrupt on either edge (i.e. from high to low or low to high)
}


/*------------------------------*/
/* UART communication functions */
/*------------------------------*/
/* Initialize the UART for TX (115200, 8N1) */
void init_uart(void)
{
	//Use UART port through debug interface
	// Connect to UART with TX (115200, 8N1)
	BOARD_InitBootPins();
	BOARD_InitBootClocks();
	BOARD_InitDebugConsole();
}

void uart_putc (char ch)
{
	/* Wait until space is available in the FIFO */
	while(!(UART0->S1 & UART_S1_TDRE_MASK));
	/* Send the character */
	UART0->D = (uint8_t)ch;
}

void uart_puts(char *ptr_str)
{
	while(*ptr_str){
	/* Replace newlines with \r\n carriage return */
	if(*ptr_str == '\n') { uart_putc('\r'); }
		uart_putc(*ptr_str++);
	}

}

void short_delay()
{
	for(int i=500; i>0; i--){}
}
// **********8

void PORTC_PORTD_IRQHandler(void) {
	uart_puts("S");
	PORTC->PCR[SWITCH_1_PIN] |= PORT_PCR_ISF(1);  // clear the interrupt status flag by writing 1 to it
}



int main(void) {
	LED_Initialize();
	init_uart();
	//uart_puts("Hello There Again!\n"); //Note the difference between "" and ''
	//'' is used for single characters
	//"" is used for strings
	setupADC();
	setupSwitch();

	//NVIC_EnableIRQ(PORTC_PORTD_IRQn);

	while(1){
		int valx = getFirstADCValue();
		int valy = getSecondADCValue();

		if (valx >= 130 && valy < 2) { // Condition for left movement
			uart_puts("L ");
			LEDRed_On();
		}
		else if (valx >=130 && valy==255) { // Condition for right movement
			uart_puts("R ");
			LEDGreen_On();
		}
		else if(valx <= 30 && valy >= 50){ //conditions for up "jump" movement
			uart_puts("U ");
			LEDGreen_On();
			LEDRed_On();
		}
		else {
			LED_Off();
			uart_puts("EMPTY ");
		}
		// We tried to implement the SW1 to control flapping wings however we realized it would be a better design choice
		// to not have an interrupt in our controls
		
//		if((PORTC->PCR[SWITCH_1_PIN] & PORT_PCR_ISF(1)) != 0) {
//			uart_puts("S ");
//			PORTC->PCR[SWITCH_1_PIN] |= PORT_PCR_ISF(1);  // clear the interrupt status flag by writing 1 to it
//		}

		uart_puts("\n");
	}
	return 0 ;
}
